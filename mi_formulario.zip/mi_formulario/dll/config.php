<?php

	/*Datos de la aplicaciòn */

	$site_name="Sistema de registro UTPL";
	$url_site="http://127.0.0.1/ingenieria_web/mi_formulario/";

	/*Datos de l base de datos*/
	$db_usr="root";
	$db_pass="";
	$db_name="web";
	$db_host="127.0.0.1";
	
	
	
?>